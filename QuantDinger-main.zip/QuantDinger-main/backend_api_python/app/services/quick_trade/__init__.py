"""Quick trade service package."""
