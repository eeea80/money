"""Pending-order execution services."""
