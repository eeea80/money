"""Market module registry package."""

